package com.QuickOrder.QuickOrder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
