package com.QuickOrder.QuickOrder.controller;

import com.QuickOrder.QuickOrder.model.Estado;
import com.QuickOrder.QuickOrder.model.QuickOrderModel;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import com.QuickOrder.QuickOrder.service.Service;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/api/pedidos")
@RestController
@RequiredArgsConstructor
public class QuickOrderController {
    private final Service service;

    @PostMapping
    public ResponseEntity<QuickOrderModel> crearPedido(@Valid @RequestBody QuickOrderModel pedido){
        QuickOrderModel nuevoPedido = service.crearPedido(pedido);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<QuickOrderModel>> obtenerTodos(){
        List<QuickOrderModel> pedidos = service.obtenerTodosLosPedidos();
        return new ResponseEntity<>(pedidos, HttpStatus.OK);

    }
    @GetMapping("/{id}")
    public ResponseEntity <QuickOrderModel> obtenerPorId(@PathVariable Long id){
        return service.obtenerPedidoPorId(id)
                .map(pedido -> new ResponseEntity<>(pedido, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
    @PutMapping("/{id}")
    public ResponseEntity<QuickOrderModel> actualizarPedido(@PathVariable Long id, @RequestBody QuickOrderModel pedidoActualizado) {
        QuickOrderModel pedido = service.actualizarPedido(id, pedidoActualizado);
        return new ResponseEntity<>(pedido, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarPedido(@PathVariable Long id) {
        service.eliminarPedido(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<QuickOrderModel>> obtenerPorEstado(@PathVariable Estado estado) {
        List<QuickOrderModel> pedidos = service.obtenerPedidosPorEstado(estado);
        return new ResponseEntity<>(pedidos, HttpStatus.OK);
    }

}
