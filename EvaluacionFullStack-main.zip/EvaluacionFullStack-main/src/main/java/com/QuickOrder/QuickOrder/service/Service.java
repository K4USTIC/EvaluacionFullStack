package com.QuickOrder.QuickOrder.service;


import com.QuickOrder.QuickOrder.model.Estado;
import com.QuickOrder.QuickOrder.model.QuickOrderModel;
import com.QuickOrder.QuickOrder.repository.Repository;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@org.springframework.stereotype.Service
@RequiredArgsConstructor

public class Service {
    private final Repository repository;

    public QuickOrderModel crearPedido(QuickOrderModel pedido){
        pedido.setFechaPedido(LocalDate.now());// toma la fecha actual
        return repository.save(pedido);
    }

    public List<QuickOrderModel> obtenerTodosLosPedidos(){
        return repository.findAll();
    }

    public Optional<QuickOrderModel> obtenerPedidoPorId(Long id){
        return  repository.findById(id);
    }
    public QuickOrderModel actualizarPedido(Long id, QuickOrderModel pedidoActualizado) {
        return repository.findById(id).map(pedidoExistente -> {
            pedidoExistente.setDescripcion(pedidoActualizado.getDescripcion());
            pedidoExistente.setMontoTotal(pedidoActualizado.getMontoTotal());
            pedidoExistente.setEstado(pedidoActualizado.getEstado());
            pedidoExistente.setNombreCliente(pedidoActualizado.getNombreCliente());
            pedidoExistente.setTipoPedido(pedidoActualizado.getTipoPedido());

            return repository.save(pedidoExistente);
        }).orElseThrow(() -> new RuntimeException("No se encontró el pedido con el ID: " + id));
    }

    public void eliminarPedido(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
        } else {
            throw new RuntimeException("No se puede eliminar. Pedido no encontrado con ID: " + id);
        }
    }

    public List<QuickOrderModel> obtenerPedidosPorEstado(Estado estado) {
        return repository.findByEstado(estado);
    }
}
