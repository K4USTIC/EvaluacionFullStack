package com.QuickOrder.QuickOrder.repository;

import com.QuickOrder.QuickOrder.model.Estado;
import com.QuickOrder.QuickOrder.model.QuickOrderModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

@org.springframework.stereotype.Repository
public interface Repository extends JpaRepository<QuickOrderModel, Long> {
    List<QuickOrderModel> findByEstado(Estado estado);
}

